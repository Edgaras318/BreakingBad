<template>
  <div id="app">
    <Header />
    <Menu />
    <div class="main">
      <router-view />
    </div>
    <Footer />
  </div>
</template>

<script>
import Footer from "@/components/Footer";
import Menu from "@/components/Menu";
import Header from "@/components/Header.vue";

export default {
  name: "App",
  components: {
    Footer,
    Menu,
    Header
  }
};
</script>

<style lang="scss">
@import "@/assets/styles/_shared.scss";
</style>
