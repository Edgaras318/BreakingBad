<template>
  <div id="character-header">
    <div class="character-header">
      <div class="character-header__img-container">
        <img
          class="character-header__img"
          src="@/assets/breaking-bad-header.jpeg"
          alt="character header image"
        />
      </div>
    </div>
    <!-- / character-header -->
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss">
@import "@/assets/styles/_header.scss";
</style>
