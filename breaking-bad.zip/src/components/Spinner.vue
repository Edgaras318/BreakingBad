<template>
  <img class="spinner" src="@/assets/spinner.gif" alt="Loading" />
</template>

<script lang="ts">
export default {
  name: "Spinner"
};
</script>

<style>
.spinner {
  width: 200px;
  margin: auto;
  display: block;
}
</style>
