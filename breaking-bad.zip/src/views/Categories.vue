<template>
  <h1>This is categories page</h1>
</template>

<script>
export default {};
</script>

<style></style>
